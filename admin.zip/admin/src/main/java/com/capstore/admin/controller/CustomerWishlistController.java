package com.capstore.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.admin.dto.CustomerDTO;
import com.capstore.admin.dto.WishlistDTO;
import com.capstore.admin.repository.CustomerRepository;
import com.capstore.admin.repository.WishlistRepository;

@RestController
@RequestMapping("api/v1/")
public class CustomerWishlistController {

	@Autowired
	private WishlistRepository wishlistRepository;
	
	
	/*@RequestMapping(value = "customerswish", method = RequestMethod.GET)
	public List<WishlistDTO> list() {
		return wishlistRepository.findAll();
	}*/
	
	@RequestMapping(value = "customers/{id}/wishlist", method = RequestMethod.GET)
	public WishlistDTO getWish(@PathVariable Integer id) {
		return wishlistRepository.findOne(id);
	}

	/*@Autowired
	private CustomerRepository customerRepository;

	@RequestMapping(value = "customerswish", method = RequestMethod.GET)
	public List<CustomerDTO> list() {
		return customerRepository.findAll();
	}*/
	
}
