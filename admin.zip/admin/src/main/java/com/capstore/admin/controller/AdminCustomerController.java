package com.capstore.admin.controller;

import java.util.List;

//import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.admin.dto.CustomerDTO;
import com.capstore.admin.dto.WishlistDTO;
import com.capstore.admin.repository.CustomerRepository;

@RestController
@RequestMapping("api/v1/")
public class AdminCustomerController {
	
	@Autowired
	private CustomerRepository customerRepository;

	@RequestMapping(value = "customers", method = RequestMethod.GET)
	public List<CustomerDTO> list() {
		return customerRepository.findAll();
	}

/*	@RequestMapping(value = "customers", method = RequestMethod.POST)
	public CustomerDTO create(@RequestBody CustomerDTO customerDTO) {
		return customerRepository.saveAndFlush(customerDTO);
	}*/

	@RequestMapping(value = "customers/{id}", method = RequestMethod.GET)
	public CustomerDTO get(@PathVariable Integer id) {
		return customerRepository.findOne(id);
	}
	
	
/*	@RequestMapping(value = "customers/{id}", method = RequestMethod.PUT)
	public CustomerDTO update(@PathVariable Integer id, @RequestBody CustomerDTO customerDTO) {
		CustomerDTO existingCustomer = customerRepository.findOne(id);
		BeanUtils.copyProperties(customerDTO, existingCustomer);
		return customerRepository.saveAndFlush(existingCustomer);
	}

	@RequestMapping(value = "customers/{id}", method = RequestMethod.DELETE)
	public CustomerDTO delete(@PathVariable Integer id) {
		CustomerDTO existingCustomer = customerRepository.findOne(id);
		customerRepository.delete(existingCustomer);
		return existingCustomer;
	}*/

}
