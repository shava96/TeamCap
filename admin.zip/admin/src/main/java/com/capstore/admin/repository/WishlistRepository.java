package com.capstore.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capstore.admin.dto.WishlistDTO;

public interface WishlistRepository extends JpaRepository<WishlistDTO, Integer> {

}
