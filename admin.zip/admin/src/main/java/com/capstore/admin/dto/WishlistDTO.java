package com.capstore.admin.dto;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="wishlist")
public class WishlistDTO {
 
	@OneToOne(fetch = FetchType.LAZY)
	private ProductDTO product;
	
	//@EmbeddedId
	CustomerDTO id=new CustomerDTO();
	@Id
	private int customerid=id.getCustomerId();
	private int productPrice;
	
	public ProductDTO getProduct() {
		return product;
	}
	public void setProduct(ProductDTO product) {
		this.product = product;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	
}
