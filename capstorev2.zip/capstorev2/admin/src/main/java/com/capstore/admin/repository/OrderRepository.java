package com.capstore.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capstore.admin.model.OrderDTO;

public interface OrderRepository extends JpaRepository<OrderDTO, Integer> {

}
