package com.capstore.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capstore.admin.model.ReturnRequestDTO;

public interface ReturnRequestRepository extends JpaRepository<ReturnRequestDTO, Integer> {
	
	   /*@Query("select s.customerid, s.orderid,s.productid from returnrequest s")
	    List<ReturnRequestDTO> getReturnDetails();*/

}

