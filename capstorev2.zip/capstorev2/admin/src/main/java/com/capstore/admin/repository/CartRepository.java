package com.capstore.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capstore.admin.model.CartDTO;
import com.capstore.admin.model.CartKey;

public interface CartRepository extends JpaRepository<CartDTO, Integer>{

}
