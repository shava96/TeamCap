package com.capstore.admin.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name="cart")
public class CartDTO{

	@Id
	private int customerid;
	@Column(name="productid")
	private int productid;
	@Column(name="promocode")
	private String promoCode;
	@Column(name="productquantity")
	private int productQuantity;
	@Column(name="productprice")
	private int productPrice;
	@Column(name="softdelete")
	private String softdelete;
	
	/*@OneToMany(mappedBy="carts", fetch = FetchType.LAZY)
	@JsonManagedReference
	private List<ProductDTO> product;*/
	
	
	@OneToOne(targetEntity=ProductDTO.class,fetch = FetchType.LAZY)
	@JoinColumn(name = "productid",insertable = false, updatable = false)
	private ProductDTO product;
	

	
	public CartDTO() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public CartDTO(int customerid, int productid, String promoCode, int productQuantity, int productPrice,
			String softdelete) {
		super();
		this.customerid = customerid;
		this.productid = productid;
		this.promoCode = promoCode;
		this.productQuantity = productQuantity;
		this.productPrice = productPrice;
		this.softdelete = softdelete;
	}



	public int getCustomerid() {
		return customerid;
	}

	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

	public String getSoftdelete() {
		return softdelete;
	}

	public void setSoftdelete(String softdelete) {
		this.softdelete = softdelete;
	}

	public int getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}
	public String getPromoCode() {
		return promoCode;
	}
	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	/*public List<ProductDTO> getProduct() {
		return product;
	}
	public void setProduct(List<ProductDTO> product) {
		this.product = product;
	}*/
	
	
	}
