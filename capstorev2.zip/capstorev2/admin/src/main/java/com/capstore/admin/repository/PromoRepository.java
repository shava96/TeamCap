package com.capstore.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capstore.admin.model.PromoDTO;

public interface PromoRepository extends JpaRepository<PromoDTO, Integer>{

}
